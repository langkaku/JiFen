$(function(){
	$('.first>li').each(function(index,value){
		$('.first>li>i').eq(index).click(function(e){
			$('.second').eq(index).toggle()
			$('.first>li').eq(index).siblings().find('.second').hide()
			e.stopPropagation()
		})
	})
	
	$('.second>li').each(function(index,value){
		$('.second>li>i').eq(index).click(function(e){
			$('.third').eq(index).toggle()
			$('.second>li').eq(index).siblings().find('.third').hide()
			e.stopPropagation()
		})
	})

	var flag = true
	$('.ms-choice').each(function(index,value){
		$('.ms-choice').eq(index).find('div').click(function(){
			if(flag){
				$('.ms-drop').eq(index).show()
				$(this).addClass('open')
				flag = false
			}else{
				$('.ms-drop').eq(index).hide()
				$(this).removeClass('open')
				flag = true
			}
		})
	})
	
	$('#applyTab').click(function(){
		$('#search').css('display','none')
	})

	$('#applyResult').click(function(){
		$('#search').css('display','none')
	})

	$('.dropdown-menu>li').click(function(){
		$('#search').css('display','block')
	})

	$('.second>li>a').click(function(){
		$('#tab2').addClass('active in')
		$('#tab2').siblings().removeClass('active in')
	})

	$('.third').click(function(){
		$('#tab3').addClass('active in')
		$('#tab3').siblings().removeClass('active in')
	})
	
})