$.extend($.fn.treegrid.defaults, {
    expanderTemplate: '<i class="treegrid-expander"></i>',
    expanderExpandedClass: 'icon-chevron-down',
    expanderCollapsedClass: 'icon-chevron-right'
});
